package com.cg.service;

import com.cg.dao.EmployeeDAO;
import com.cg.dao.EmployeeDAOImpl;

public class EmployeeServiceImpl implements EmployeeService {

	
	EmployeeDAOImpl dao;
	public EmployeeServiceImpl(EmployeeDAOImpl dao) {
		
		this.dao = dao;
	}

	public void getEmployeeById(int choice) {
		// TODO Auto-generated method stub
      dao.getEmployeeById(choice);
	}

}
