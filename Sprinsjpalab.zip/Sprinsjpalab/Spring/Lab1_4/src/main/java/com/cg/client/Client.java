package com.cg.client;

import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.service.EmployeeServiceImpl;

public class Client {
	
	
	
	public static void main (String arg[]) {
		Scanner sc=new Scanner(System.in);
	int choice;
	System.out.println("enter your choice\n1.101\n2.101\n3.103");
	
	choice=sc.nextInt();
	
	ApplicationContext context=new ClassPathXmlApplicationContext("spring.xml");
	EmployeeServiceImpl service=(EmployeeServiceImpl) context.getBean("emp");
	service.getEmployeeById(choice);

}
}