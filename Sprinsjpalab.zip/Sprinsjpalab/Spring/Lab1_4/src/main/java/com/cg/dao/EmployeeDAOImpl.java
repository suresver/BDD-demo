package com.cg.dao;

import java.util.HashMap;
import java.util.Map;

import com.cg.bean.Employee;

public class EmployeeDAOImpl implements EmployeeDAO {

	Map<Integer,Employee> map;
	public void getEmployeeById(int choice) {
		
		switch (choice) {
		case 1:
			System.out.println(map.get(101));
			break;
		case 2:
			System.out.println(map.get(102));
			break;
		case 3:
			System.out.println(map.get(103));
			break;

		default:
			System.out.println("Worng choice");
			break;
		}
		
		
	}
	public Map<Integer, Employee> getMap() {
		return map;
	}
	public void setMap(Map<Integer, Employee> map) {
		this.map = map;
	}
	@Override
	public String toString() {
		return "EmployeeDAOImpl [map=" + map + "]";
	}
	

}
