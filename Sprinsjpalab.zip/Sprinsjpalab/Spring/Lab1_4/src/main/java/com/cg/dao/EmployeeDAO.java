package com.cg.dao;

import com.cg.bean.Employee;

public interface EmployeeDAO {

	 public void getEmployeeById(int choice);
}
