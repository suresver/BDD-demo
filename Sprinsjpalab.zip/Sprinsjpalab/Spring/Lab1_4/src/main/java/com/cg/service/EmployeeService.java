package com.cg.service;

public interface EmployeeService {

	public void getEmployeeById(int choice);
}
