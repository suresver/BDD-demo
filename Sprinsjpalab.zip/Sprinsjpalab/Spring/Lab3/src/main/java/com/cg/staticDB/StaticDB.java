package com.cg.staticDB;

import java.util.ArrayList;
import java.util.List;

import com.cg.bean.Product;

public class StaticDB {

	static List<Product>prodList=new ArrayList<>();
	
	static {
		
		
		
		Product p1=new Product("Laptop",101,45678.34);
		Product p2=new Product("Ipad",102,65748.34);
		Product p3=new Product("IPhone",103,84655.34);
		Product p4=new Product("IPod",104,45769.34);
		Product p5=new Product("Hard Disk",105,5000.34);
		Product p6=new Product("Data Cables",106,1000.34);
		Product p7=new Product("Adapter",107,500.34);
		Product p8=new Product("DVD",108,345567.34);
		
		prodList.add(p1);
		prodList.add(p2);
		prodList.add(p3);
		prodList.add(p4);
		prodList.add(p5);
		prodList.add(p6);
		prodList.add(p7);
		prodList.add(p8);
		
	}

	public static  List<Product> showAllProducts(){
		return prodList;
	}
}
