package com.cg.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.staticDB.StaticDB;
import com.cg.bean.Product;
import java.util.*;
@RestController

public class HomeController {

	@RequestMapping("/product-list")
	public List<Product> productList(){
		List<Product> prodList;
		prodList=StaticDB.showAllProducts();
		return prodList;
	}
}
