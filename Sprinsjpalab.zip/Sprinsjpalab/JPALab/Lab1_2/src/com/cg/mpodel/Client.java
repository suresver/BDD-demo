package com.cg.mpodel;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Client {
	public static void main(String args[]) {
		
EntityManagerFactory factory=Persistence.createEntityManagerFactory("JPA-PU");
EntityManager em=factory.createEntityManager();
Author author=new Author();
author.setAuthorId(101);
author.setFirstName("Aniket");
author.setMiddleName("Kumar");
author.setLastName("Pal");
author.setPhoneNo("83360344454");
em.getTransaction().begin();
em.persist(author);
em.getTransaction().commit();
em.close();
factory.close();
	}
}
