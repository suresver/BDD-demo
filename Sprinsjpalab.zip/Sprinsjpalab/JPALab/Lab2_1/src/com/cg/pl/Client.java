package com.cg.pl;

import java.util.List;

import javax.persistence.EntityManager;

import com.cg.dao.JPAUtils;
import com.cg.entities.Author;
import com.cg.service.AuthorServiceImpl;
import com.cg.service.AuthorSrevice;

public class Client {

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AuthorSrevice service=new AuthorServiceImpl();
    EntityManager em;
   em= JPAUtils.getEntityManager();
   
   Author author=new Author(101,"Suresh","Kumar","Verma","8574937487");
   Author author1=new Author(102,"Umang","Kumar","Gupta","8545938487");
   Author author2=new Author(103,"Aniket","Kumar","Pal","8976537487");
   service.addAuthor(author1);
   service.addAuthor(author2);
   service.addAuthor(author);
   System.out.println(service.getById(103));
   author2.setLastName("Jallaad");
   service.updateAuthor(author2);
   List<Author> authList= service.getAllAuthors();
   for(Author a:authList) {
	   System.out.println(a);
   }
   em.close();
   
	}

}
