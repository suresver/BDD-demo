package com.cg.dao;

import java.util.List;

import com.cg.entities.Author;

public interface AuthorDAO {
	public List<Author> getAllAuthors();
	public Author getById(int id);
	public void addAuthor(Author author);
	public void updateAuthor(Author author);
	public void deleteAuthor(Author author);
	public void getTransactionBegin();
	public void gettransactioncommit();

}
