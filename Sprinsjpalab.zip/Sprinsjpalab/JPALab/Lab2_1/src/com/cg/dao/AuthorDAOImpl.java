package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import com.cg.entities.Author;

public class AuthorDAOImpl implements AuthorDAO {
  EntityManager em=JPAUtils.getEntityManager();
	@Override
	public Author getById(int id) {
		// TODO Auto-generated method stub
		return em.find(Author.class, id);
	}

	@Override
	public void addAuthor(Author author) {
		// TODO Auto-generated method stub
     em.persist(author);
	}

	@Override
	public void updateAuthor(Author author) {
		// TODO Auto-generated method stub
	     em.persist(author);
	}

	@Override
	public void deleteAuthor(Author author) {
		// TODO Auto-generated method stub
	     em.remove(author);
	}

	@Override
	public void getTransactionBegin() {
		// TODO Auto-generated method stub
		em.getTransaction().begin(); 
	}

	@Override
	public void gettransactioncommit() {
		// TODO Auto-generated method stub
		em.getTransaction().commit(); 
	}

	@Override
	public List<Author> getAllAuthors() {
		String sts="Select author from Author author";
		TypedQuery<Author> tQuery= em.createQuery(sts,Author.class);
		List<Author> authList=tQuery.getResultList();
		return authList;
		}
		
	}
