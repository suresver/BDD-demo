package com.cg.model;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Client {

	public static void main(String argc[]) {
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em=factory.createEntityManager();
		em.getTransaction().begin();
		Greet greet=new Greet();
		greet.setMessage("Welcome to JPA!");
		greet.setMessageId(101);
		em.persist(greet);
		System.out.println("Added greeting to database");
		em.getTransaction().commit();
		em.clear();
		factory.close();
	}
}
