package com;

import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Demo1 {

	public static void main(String[] args) throws InterruptedException
	{
		System.setProperty("webdriver.chrome.driver","C:\\BDD Jar Files\\chromedriver_win32\\chromedriver.exe");
	 	WebDriver driver=new ChromeDriver();
  		driver.get("https:\\www.google.com");
 		driver.manage().window().maximize();
 		//WebElement li=driver.findElement(By.xpath("//img[@src='/images/branding/googlelogo/2x/googlelogo_color_272x92dp.png']"));
 		WebElement li=driver.findElement(By.xpath("//img[@id='hplogo']"));
// 		WebElement li=driver.findElement(By.id("hplogo"));
 		if(li.isDisplayed())
	    	{
		    	 System.out.println("image is present -No defect");
	    	}
		else
		    {
			
			System.out.println("image is not present -A Defect");
		    }
 	//Actions a=new Actions(driver);
 	//a.moveToElement(li).clickAndHold(li).build().perform();
			System.out.println("title of google image is"+li.getAttribute("alt"));

 	 if(li.getAttribute("alt").equalsIgnoreCase("Google"))
 	    	{
 		    	 
 			System.out.println("title of google image is correct -No defect");
 	    	}
 		else
 		    {
 			System.out.println("title of google image is not correct -A defect");
 		    }
 	 
 	 
 		WebElement li5=driver.findElement(By.name("q"));
	 		//Actions a1=new Actions(driver);
	 	//a1.moveToElement(li5).clickAndHold(li5).build().perform();
			System.out.println("title of google text box is"+li5.getAttribute("title"));

	 	 if(li5.getAttribute("title").equalsIgnoreCase("Search"))
	 	    	{
	 		    	 
	 			System.out.println("title of google text box is correct -No defect");
	 	    	}
	 		else
	 		    {
	 			System.out.println("title of google text box is not correct -A defect");
	 		    }
	
	 		driver.findElement(By.linkText("Images")).sendKeys(Keys.CONTROL,Keys.RETURN);
	 		
	 		ArrayList<String> tw = new ArrayList<String>(driver.getWindowHandles());
		    int size=tw.size();
		 	System.out.println("No of opened windows="+size);
		 	
	 
			for(int i=0;i<tw.size();i++)
			{
				
			 	System.out.println(tw.get(i));
				
				if(i==1)
				{
					driver.switchTo().window(tw.get(i));
				 	break;


				}
				
			}
			
			driver.getCurrentUrl();
			System.out.println(driver.getCurrentUrl());
			driver.findElement(By.name("q")).sendKeys("cars");
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			driver.findElement(By.name("q")).sendKeys(Keys.ENTER);
			Thread.sleep(5000);
			driver.quit();
}
}
