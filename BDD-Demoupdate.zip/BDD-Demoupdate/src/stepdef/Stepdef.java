package stepdef;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Stepdef {

	WebDriver d;
	@Given("^Open ksrtc web site$")
	public void open_ksrtc_web_site() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "C:\\BDD Jar Files\\chromedriver_win32\\chromedriver.exe");
  	  d=new ChromeDriver();
      d.get("http://www.ksrtc.in/oprs-web/");
      d.manage().window().maximize();
		
		
	    
	}

	@When("^user inputs \"([^\"]*)\" and \"([^\"]*)\"$")
	public void user_inputs_and(String name, String password) throws Throwable {//*[@id="userName"]
		

    	d.findElement(By.linkText("Sign In")).click();

  		Thread.sleep(2000);
  		d.findElement(By.xpath("//*[@id='userName']")).sendKeys(name);
  		d.findElement(By.xpath("//*[@id='password']")).sendKeys(password);
  		d.findElement(By.xpath("//*[@id='submitBtn']")).click();
	    
	}

	@Then("^Login should be successfull$")
	public void login_should_be_successfull() throws Throwable {
		d.quit();
	}

}
