package runner;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(features={"C:\\BDDDEMOeclipse-workspace\\BDD-Demoupdate\\featurefiles\\ani.Feature"},
glue="Stepdef",
plugin = {"pretty", "html:target/suresh-report"},
monochrome=true,
dryRun=false

)
public class Run {

}
